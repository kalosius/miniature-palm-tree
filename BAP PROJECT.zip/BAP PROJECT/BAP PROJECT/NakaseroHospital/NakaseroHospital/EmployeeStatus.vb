﻿Public Class EmployeeStatus

    Private Sub Label32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label32.Click
        Dashboard.Show()
        Me.Hide()
    End Sub

    Private Sub Label30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label30.Click
        AllEmployees.Show()
        Me.Hide()
    End Sub

    Private Sub Label31_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label31.Click
        Administrators.Show()
        Me.Hide()
    End Sub

    Private Sub Label27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label27.Click
        managers.Show()
        Me.Hide()
    End Sub

    Private Sub Label29_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label29.Click

    End Sub

    Private Sub Label28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label28.Click
        Login.Show()
        Me.Hide()
        MessageBox.Show("Successfully Logged out")
    End Sub

   

    Private Sub EmployeeStatus_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label14.Text = Date.Now.ToString("dddd, dd MMMM yyyy hh:mm tt")
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Label11.Text = Date.Now.ToString("dddd, dd MMMM yyyy hh:mm tt")
        Button2.Text = "Signed Out"
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Edit.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim result As DialogResult
        result = MessageBox.Show("Are you sure you want to delete the account?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)

        If result = DialogResult.Yes Then
            MessageBox.Show("Account deleted.")
            Login.Show()
            Me.Hide()
        Else
            MessageBox.Show("Deletion cancelled.")
        End If


    End Sub
End Class