﻿Imports System.Data.SqlClient

Public Class Register

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim connectionString As String = "Data Source=localhost;Initial Catalog=nakaserodb;Integrated Security=True"
        Dim con As New SqlConnection(connectionString)

        Try
            con.Open()

            Dim query As String = "INSERT INTO employee (FirstName, LastName, Email, Password, Role) VALUES (@FirstName, @LastName, @Email, @Password, @Role)"
            Dim cmd As New SqlCommand(query, con)

            cmd.Parameters.AddWithValue("@FirstName", firstname.Text)
            cmd.Parameters.AddWithValue("@LastName", lastname.Text)
            cmd.Parameters.AddWithValue("@Email", email.Text)
            cmd.Parameters.AddWithValue("@Password", password.Text)
            cmd.Parameters.AddWithValue("@Role", RoleComboBox1.Text)

            cmd.ExecuteNonQuery()

            MessageBox.Show("User registered successfully!")
            Dashboard.Show()
            Me.Hide()

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            con.Close()
        End Try
        Dashboard.Show()
        Me.Hide()
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Login.Show()
        Me.Hide()
    End Sub

End Class