﻿Imports System.Data.SqlClient

Public Class Dashboard

    Private Function GetUserCountByRole(ByVal role As String) As Integer
        Dim count As Integer = 0
        Dim connectionString As String = "Data Source=YOUR_SERVER;Initial Catalog=YOUR_DATABASE;Integrated Security=True"

        Using con As New SqlConnection(connectionString)
            Try
                con.Open()
                Dim query As String = "SELECT COUNT(*) FROM Users WHERE Role = @Role"
                Dim cmd As New SqlCommand(query, con)
                cmd.Parameters.AddWithValue("@Role", role)
                count = Convert.ToInt32(cmd.ExecuteScalar())
            Catch ex As Exception
                MessageBox.Show("Error: " & ex.Message)
            End Try
        End Using

        Return count
    End Function


    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click
        AllEmployees.Show()
        Me.Hide()
    End Sub

   

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click
        Login.Show()
        MessageBox.Show("Successfully Logged out")
        Me.Hide()
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click
        Administrators.Show()
        Me.Hide()

    End Sub

    Private Sub Label9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label9.Click
        managers.Show()
        Me.Hide()
    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click
        EmployeeStatus.Show()
        Me.Hide()
    End Sub

    Private Sub totalEmployees_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles totalEmployees.Click
        totalEmployees.Text = "Employees: " & GetUserCountByRole("Employee")
    End Sub

    Private Sub totalManagers_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles totalManagers.Click
        totalManagers.Text = "Managers: " & GetUserCountByRole("Manager")
    End Sub

    Private Sub totalAdmin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles totalAdmin.Click
        totalAdmin.Text = "Admins: " & GetUserCountByRole("Admin")
    End Sub

    'Load counts automatically on form load
    Private Sub Dashboard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        totalEmployees.Text = "Employees: " & GetUserCountByRole("Employee")
        totalManagers.Text = "Managers: " & GetUserCountByRole("Manager")
        totalAdmin.Text = "Admins: " & GetUserCountByRole("Admin")
    End Sub


    Private Sub GroupBox5_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox5.Enter
        ' Clear existing controls
        GroupBox5.Controls.Clear()

        Dim connectionString As String = "Data Source=localhost;Initial Catalog=nakaserodb;Integrated Security=True"
        Dim con As New SqlConnection(connectionString)

        Try
            con.Open()
            Dim query As String = "SELECT FirstName, Email FROM Users WHERE Role = 'Employee'"
            Dim cmd As New SqlCommand(query, con)
            Dim reader As SqlDataReader = cmd.ExecuteReader()

            Dim yOffset As Integer = 20
            While reader.Read()
                ' creating the label for First Name
                Dim nameLabel As New Label()
                nameLabel.Text = "Name: " & reader("FirstName").ToString()
                nameLabel.Location = New Point(10, yOffset)
                nameLabel.AutoSize = True
                GroupBox5.Controls.Add(nameLabel)

                ' creating the label for Email
                Dim emailLabel As New Label()
                emailLabel.Text = "Email: " & reader("Email").ToString()
                emailLabel.Location = New Point(150, yOffset)
                emailLabel.AutoSize = True
                GroupBox5.Controls.Add(emailLabel)

                yOffset += 25 ' Moving down for the next entry
            End While

            reader.Close()

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            con.Close()
        End Try
    End Sub

End Class