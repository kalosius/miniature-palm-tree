﻿Imports System.Data.SqlClient
Public Class Edit

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged

    End Sub

    Private Sub Label25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label25.Click
        Dashboard.Show()
        Me.Hide()
    End Sub

    Private Sub Label23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label23.Click
        AllEmployees.Show()
        Me.Hide()
    End Sub

    Private Sub Label24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label24.Click
        Administrators.Show()
        Me.Hide()
    End Sub

    Private Sub Label20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label20.Click
        managers.Show()
        Me.Hide()
    End Sub

    Private Sub Label22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label22.Click
        EmployeeStatus.Show()
        Me.Hide()
    End Sub

    Private Sub Label21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label21.Click
        Login.Show()
        Me.Hide()
        MessageBox.Show("Successfully Logged Out")
    End Sub

    Private Sub btnUpload_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpload.Click
        'Creating an OpenFileDialog to allow the user to select an image
        Dim openFileDialog As New OpenFileDialog()

        'Setting the  filter 4 image files (e.g., JPG, PNG)
        openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif"

        'Showing the file dialog and checkng if e user selected a file
        If openFileDialog.ShowDialog() = DialogResult.OK Then
            'Loading the selected image into the PictureBox
            picProfile.Image = Image.FromFile(openFileDialog.FileName)

            'specific location where files are to be saved
            Dim savePath As String = "C:\Users\Public\Pictures\" & "profile_picture.jpg"
            picProfile.Image.Save(savePath)
            picProfile.SizeMode = PictureBoxSizeMode.StretchImage 'resizing out image after upload
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.Close()
        AllEmployees.Show()
    End Sub


    'saving the updated details
    Private Sub editsavebtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles editsavebtn.Click

        Dim connectionString As String = "Data Source=localhost;Initial Catalog=nakaserodb;Integrated Security=True"
        Dim con As New SqlConnection(connectionString)

        Try
            con.Open()


            Dim query As String = "UPDATE employee SET FirstName = @FirstName, LastName = @LastName, Email = @Email, Role = @Role WHERE UserID = @UserID"
            Dim cmd As New SqlCommand(query, con)


            cmd.Parameters.AddWithValue("@FirstName", firstname.Text)
            cmd.Parameters.AddWithValue("@LastName", lastname.Text)
            cmd.Parameters.AddWithValue("@Email", email.Text)
            cmd.Parameters.AddWithValue("@Role", editRoleComboBox.SelectedItem.ToString())
            cmd.Parameters.AddWithValue("@UserID", userIdLabel.Text)

            Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

            If rowsAffected > 0 Then
                MessageBox.Show("User details updated successfully!")
            Else
                MessageBox.Show("No changes were made.")
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            con.Close()
        End Try
    End Sub
End Class