﻿Imports System.Data.SqlClient

Public Class Login

    

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim connectionString As String = "Data Source=localhost;Initial Catalog=nakaserodb;Integrated Security=True"
        Dim con As New SqlConnection(connectionString)
        Dashboard.Show()
        Me.Hide()

        Try
            con.Open()

            Dim query As String = "SELECT COUNT(*) FROM employee WHERE FirstName = @FirstName AND Password = @Password AND Role = @Role"
            Dim cmd As New SqlCommand(query, con)

            cmd.Parameters.AddWithValue("@FirstName", username.Text)
            cmd.Parameters.AddWithValue("@Password", password.Text)
            cmd.Parameters.AddWithValue("@Role", RoleComboBox1.Text)

            Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())

            If count > 0 Then
                MessageBox.Show("Login successful!")
                Dashboard.Show()
                Me.Hide()
            Else
                MessageBox.Show("Invalid credentials. Please try again. Or Register for an Account")
            End If

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            con.Close()
        End Try
        Dashboard.Show()
        Me.Hide()
    End Sub


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Register.Show()
        Me.Hide()
    End Sub

End Class